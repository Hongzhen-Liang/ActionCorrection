import matplotlib.pyplot as plt
from pandas.core.frame import DataFrame
import numpy as np
from scipy.fftpack import fft,ifft
# 绘图函数
def plot_photo(data,title):
    plt.figure()
    plt.plot(data)
    plt.title(title)
    plt.show()

# 移动窗口函数
def get_move_window(mean_semg,windowlength):
    mean_semg_arr = DataFrame(mean_semg)
    mean_semg_arr = mean_semg_arr.rolling(windowlength).mean()
    mean_semg_arr = np.array(mean_semg_arr)
    return mean_semg_arr

# 求平均数函数
def mean(data):
    sum = 0
    len_data=len(data)
    for i in range(len_data):
        sum+=data[i]
    return sum/len_data

# 求起止点函数
def cut_sta_end(data,thre,windowlength):
    data=data.values
    move_win = []
    for j in range(windowlength):
        move_win.append(data[j][0])
    sta = True
    end = False
    sta_num = end_num = jump_value = 0
    for j in range(windowlength,len(data)):
        move_win[:-1]=move_win[1:]
        move_win[windowlength-1]=data[j][0]
        
        # 每隔100才做一次计算
        jump_value+=1
        if jump_value<100:
            continue
        jump_value=0
        
        if sta and mean(move_win)>thre:
            # print('起',j)
            sta_num  = j
            sta = False
            end = True
        elif end and mean(move_win)<thre:
            # print('落',j)
            end_num = j
            sta = True
            end = False
            if end_num-sta_num<2500:
                print('持续时间不够')
            else:
                break
    return sta_num,end_num

def sEmg_train(mav_action,Action,thre,windowlength):
    for i in range(len(Action)):
        sta,end=cut_sta_end(Action[i],thre,windowlength)
        tmp = Action[i][sta:end]
        # print(tmp)
        print(sta,end)
        mav_action.loc[i,'ch1_mean']=tmp.ch1.mean()
        mav_action.loc[i,'ch1_pow_mean']=((tmp.ch1)**2).mean()
        mav_action.loc[i,'ch1_len']=end-sta
        data_cut1 = []
        for j in range(len(tmp)):
            data_cut1.append(tmp.values[j][0])
        # plot_photo(data_cut1,'fft')
        yy = abs(fft(data_cut1))
        mav_action.loc[i,'ch1_fft_mean']=mean(yy)

